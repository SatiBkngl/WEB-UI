package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import utilities.Action;
import utilities.Driver;

public class TeknosaMagazaBulPage {

    public TeknosaMagazaBulPage() {
        PageFactory.initElements(Driver.getDriver() , this);
    }

    public static final By ilAdi = By.xpath("//select[@id='cities1']");

    public static final By ilceAdi = By.xpath("//select[@id='towns']");
    public static void ilAdiSecilir() {
        Action.clickElement(ilAdi);
        Action.sendKeysElement(ilAdi, "Antalya");
        Action.pressEnter(ilAdi);
    }

    public static void ilceAdiSecilir() {
        Action.clickElement(ilceAdi);
        Action.sendKeysElement(ilceAdi, "Manavgat");
        Action.pressEnter(ilceAdi);
    }



}




