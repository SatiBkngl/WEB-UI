package stepdefinitions;

import io.cucumber.java.en.And;
import pages.TeknosaMagazaBulPage;

public class TeknosaMagazaBulSteps {

    TeknosaMagazaBulPage teknosamagazabulpage = new TeknosaMagazaBulPage();
    
    @And("Magaza Bulucu formundan <il adı> seçimi yapılır")
    public void magazaIlAdiSecimiYapilir() {
        TeknosaMagazaBulPage.ilAdiSecilir();
           }
    @And("Magaza Bulucu formundan <ilce adı> seçimi yapılır")
    public void magazaIlceAdiSecimiYapilir() {
        TeknosaMagazaBulPage.ilceAdiSecilir();
    }
}
